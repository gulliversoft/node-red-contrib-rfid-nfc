# Simple script to get the version of the Raspberry Pi that we're running on
import RPi.GPIO as GPIO
print GPIO.RPI_REVISION
